# Neuro-Symbolic FinDKG experiments

This directory is an isolated, additive experiment area. The original DKG implementation, dataset files, and existing outputs remain untouched.

## Dataset roles established from this checkout

- `../FinDKG_dataset/FinDKG` is the controlled study benchmark used by the current training script (`graph_mode = "FinDKG"`). It has 13,645 entities, 15 relations, and 144,062 quadruples across chronological train/validation/test periods (time IDs 0–99, 100–112, and 113–125).
- `../FinDKG_dataset/FinDKG-full` is the larger future-research variant: 242,149 quadruples, time IDs 0–260, and a `time2id.txt` date mapping. It is not the initial controlled benchmark.

These are graph datasets, not raw news articles. The notebook `../notebooks/02_ickg_extraction_demo.py` is an API demonstration over five hard-coded examples; it is not the original ICKG model or the source corpus pipeline.

## Phased implementation status

1. Repository and dataset audit: complete. Findings are in `reports/phase_1_audit.md`.
2. Article acquisition and extraction setup: unavailable for this study. No article text is supplied. Do not infer article text from graph triples or present graph-only filtering as extraction validation.
3. Graph-level symbolic constraints: implemented in `graph_symbolic.py`. It checks ID ranges, type-map coverage, split time bounds, cross-split overlap, and chronological ordering. Repeated quadruples/facts are recorded as recurrence statistics and preserved. It writes per-row accept/reject audit entries and a summary. It cannot validate semantic support or objective truth.
4. Neural-symbolic controlled experiments: planned on the study benchmark. The neural component is the unchanged KGTransformer; the symbolic component audits and filters graph records using explicit rules before graph loading. Baseline checkpoints/logs are absent from this checkout; the checked-in training config differs from the stated baseline patience.

The isolated experiment runner is `run_experiment.py`. It copies both conditions under a unique run folder, applies symbolic rules, hashes source inputs, records environment/config, launches each condition with separate logs/checkpoints, and parses test metrics into the manifest. It patches the legacy logger within each copied run script so outputs stay inside the run folder. Example:

```powershell
python neurosymbolic/run_experiment.py --dataset FinDKG --run-id my_run --train --max-epochs 150 --patience 20
```

This workspace currently lacks DGL and `torch_scatter`, so a local model run stops before training with those dependencies listed in the run manifest. The current audit accepts all rows; the symbolic-filtered condition therefore has the same triples as baseline. This is a necessary control showing that the implemented hard constraints alone do not alter this dataset. Additional symbolic hypotheses require defensible graph semantics and must be selected without test-set tuning.

## Running the API-independent checks

From `FinDKG` run:

```powershell
python -m unittest discover -s neurosymbolic -p "test_*.py"
```

The checks exercise claim-schema behavior and graph-level symbolic constraints on small software fixtures. Run a real dataset audit with:

```powershell
python neurosymbolic/graph_symbolic.py FinDKG_dataset/FinDKG neurosymbolic/results/FinDKG_symbolic_audit
```

Passing software checks or graph consistency audits does not establish extraction accuracy, article evidence, or financial truth.

## Pasted Kaggle run artifact

The user supplied a Kaggle notebook transcript that includes an R-GCN+RNN run on `FinDKG` with seed 41, a 15 GB Kaggle T4 noted in the script context, and patience 20. Logged test results: loss 137.3764, MRR 0.116748, Rec@1 0.073839, Rec@3 0.128778, Rec@10 0.198561, Rec@100 0.369959. This is a supplied run transcript, not a checkpoint independently reproduced in this workspace. It is an R-GCN variant, not the KGTransformer baseline and not an extraction/verification experiment.

## Data layout

- `data/articles/`: source articles in JSONL (one record per article; retain text, timestamp, source, URL/document ID, author and metadata).
- `data/claims/`: raw candidate and adjudicated claim JSONL.
- `data/verified_graph/`: exported four-column FinDKG-compatible candidates, with provenance kept separately.
- `rules/`: versioned symbolic constraints.
- `configs/`: experiment configuration snapshots.
- `results/`: run summaries and audit logs.
- `reports/`: phase reports and final research report.

No synthetic article or claim is supplied as research data. The example in tests is clearly synthetic and used only to check software behavior.
